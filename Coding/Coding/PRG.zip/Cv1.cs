﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coding
{
    internal class Cv1
    {
        static void Main(string[] args)
        {
            for (int i = 1; i < 8; i++)
            {

                for (int j = 0; j < i; j++)
                {
                    Console.Write(i);
                    
                }
                
                Console.WriteLine("");
            }

            Console.ReadLine();
        }

    }
}
